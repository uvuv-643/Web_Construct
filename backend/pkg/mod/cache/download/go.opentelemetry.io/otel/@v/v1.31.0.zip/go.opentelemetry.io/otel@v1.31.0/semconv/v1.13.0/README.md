# Semconv v1.13.0

[![PkgGoDev](https://pkg.go.dev/badge/go.opentelemetry.io/otel/semconv/v1.13.0)](https://pkg.go.dev/go.opentelemetry.io/otel/semconv/v1.13.0)
